<?php
require_once "includes/db.php";
require_once "includes/auth.php";

require_login();
$page_title = "Dashboard";

// Metric counters
$total_users = (int) $conn->query("SELECT COUNT(*) FROM users")->fetch_row()[0];
$total_medicines = (int) $conn->query("SELECT COUNT(*) FROM medicines")->fetch_row()[0];
$total_stock = (int) $conn->query("SELECT COALESCE(SUM(current_stock), 0) FROM inventory")->fetch_row()[0];
$total_sales = (float) $conn->query("SELECT COALESCE(SUM(total_amount), 0) FROM sales")->fetch_row()[0];
$total_purchases = (float) $conn->query("SELECT COALESCE(SUM(total_amount), 0) FROM purchases WHERE purchase_status = 'Received'")->fetch_row()[0];
$sales_count = (int) $conn->query("SELECT COUNT(*) FROM sales")->fetch_row()[0];

$profit_loss = 0.00;
$low_stock_items = [];
$near_expiry_items = [];

// Admin & Pharmacist statistics
if (role_is("Admin", "Pharmacist")) {
    $p_res = $conn->query(
        "SELECT COALESCE(SUM(s.total_amount) - SUM(s.quantity_sold * m.purchase_price), 0)
         FROM sales s JOIN medicines m ON s.medicine_id = m.medicine_id"
    )->fetch_row()[0];
    $profit_loss = (float) $p_res;

    $limit = LOW_STOCK;
    $stmt = $conn->prepare(
        "SELECT m.medicine_id, m.medicine_name, i.current_stock, m.category, m.expire_date, i.stock_status
         FROM inventory i JOIN medicines m ON i.medicine_id = m.medicine_id
         WHERE i.current_stock < ? ORDER BY i.current_stock ASC"
    );
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    $low_stock_items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    $days = EXPIRY_DAYS;
    $stmt = $conn->prepare(
        "SELECT m.medicine_id, m.medicine_name, i.current_stock, m.category, m.expire_date
         FROM medicines m JOIN inventory i ON m.medicine_id = i.medicine_id
         WHERE m.expire_date <= DATE_ADD(CURDATE(), INTERVAL ? DAY) ORDER BY m.expire_date ASC"
    );
    $stmt->bind_param("i", $days);
    $stmt->execute();
    $near_expiry_items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
}

require_once "includes/header.php";
?>

<div class="cards">
    <div class="card-stat"><h3>Users</h3><p><?php echo $total_users; ?></p></div>
    <div class="card-stat"><h3>Medicines</h3><p><?php echo $total_medicines; ?></p></div>
    <div class="card-stat"><h3>Stock units</h3><p><?php echo $total_stock; ?></p></div>
    <div class="card-stat"><h3>Total sales</h3><p><?php echo number_format($total_sales, 2); ?></p></div>
    <div class="card-stat"><h3>Total purchases</h3><p><?php echo number_format($total_purchases, 2); ?></p></div>
    <div class="card-stat"><h3>Sales count</h3><p><?php echo $sales_count; ?></p></div>
    <?php if (role_is("Admin", "Pharmacist")) { ?>
    <div class="card-stat"><h3>Profit / Loss</h3><p><?php echo number_format($profit_loss, 2); ?></p></div>
    <?php } ?>
</div>

<?php if (role_is("Admin", "Pharmacist")) { ?>
<div class="card">
    <h2>Low stock (below <?php echo LOW_STOCK; ?>)</h2>
    <?php if (!$low_stock_items) { ?><p>No low stock items.</p><?php } else { ?>
    <table>
        <thead>
            <tr><th>ID</th><th>Medicine</th><th>Stock</th><th>Category</th><th>Status</th><th>Expire</th></tr>
        </thead>
        <tbody>
            <?php foreach ($low_stock_items as $row) { ?>
            <tr>
                <td><?php echo (int) $row["medicine_id"]; ?></td>
                <td><?php echo h($row["medicine_name"]); ?></td>
                <td><?php echo (int) $row["current_stock"]; ?></td>
                <td><?php echo h(medicine_category_label($row["category"])); ?></td>
                <td><?php echo h($row["stock_status"]); ?></td>
                <td><?php echo h($row["expire_date"]); ?></td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
    <?php } ?>
</div>

<div class="card">
    <h2>Near expiry (next <?php echo EXPIRY_DAYS; ?> days)</h2>
    <?php if (!$near_expiry_items) { ?><p>No near expiry items.</p><?php } else { ?>
    <table>
        <thead>
            <tr><th>ID</th><th>Medicine</th><th>Stock</th><th>Category</th><th>Expire</th></tr>
        </thead>
        <tbody>
            <?php foreach ($near_expiry_items as $row) { ?>
            <tr>
                <td><?php echo (int) $row["medicine_id"]; ?></td>
                <td><?php echo h($row["medicine_name"]); ?></td>
                <td><?php echo (int) $row["current_stock"]; ?></td>
                <td><?php echo h(medicine_category_label($row["category"])); ?></td>
                <td><?php echo h($row["expire_date"]); ?></td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
    <?php } ?>
</div>
<?php } ?>

<?php require_once "includes/footer.php"; ?>
