<?php
require_once "includes/db.php";
require_once "includes/auth.php";

require_login();
require_role("Admin");

$page_title = "Reports";
$is_monthly = strtolower($_GET["type"] ?? "daily") === "monthly";
$report_type = $is_monthly ? "Monthly" : "Daily";

$sales_date_expr = $is_monthly ? "DATE_FORMAT(s.sale_date_time, '%Y-%m-01')" : "DATE(s.sale_date_time)";
$sales_group_expr = $is_monthly ? "DATE_FORMAT(s.sale_date_time, '%Y-%m')" : "DATE(s.sale_date_time)";
$pur_date_expr = $is_monthly ? "DATE_FORMAT(purchase_date, '%Y-%m-01')" : "DATE(purchase_date)";
$pur_group_expr = $is_monthly ? "DATE_FORMAT(purchase_date, '%Y-%m')" : "DATE(purchase_date)";
$limit = $is_monthly ? 24 : 60;

$sales_reports = $conn->query(
    "SELECT $sales_date_expr AS report_date,
            SUM(s.total_amount) AS total_sales_amount,
            SUM(s.quantity_sold * m.purchase_price) AS total_purchase_cost,
            SUM(s.total_amount) - SUM(s.quantity_sold * m.purchase_price) AS profit_loss
     FROM sales s JOIN medicines m ON s.medicine_id = m.medicine_id
     GROUP BY $sales_group_expr ORDER BY report_date DESC LIMIT $limit"
)->fetch_all(MYSQLI_ASSOC);

$purchase_reports = $conn->query(
    "SELECT $pur_date_expr AS report_date, SUM(total_amount) AS total_purchase_amount
     FROM purchases WHERE purchase_status = 'Received'
     GROUP BY $pur_group_expr ORDER BY report_date DESC LIMIT $limit"
)->fetch_all(MYSQLI_ASSOC);

require_once "includes/header.php";
?>

<div class="tabs">
    <a href="reports.php?type=daily" class="<?php echo !$is_monthly ? "active" : ""; ?>">Daily</a>
    <a href="reports.php?type=monthly" class="<?php echo $is_monthly ? "active" : ""; ?>">Monthly</a>
</div>

<div class="card">
    <h2>Sales report (<?php echo h($report_type); ?>)</h2>
    <table id="data-table">
        <thead>
            <tr><th>Date</th><th>Sales</th><th>COGS</th><th>Profit / Loss</th></tr>
        </thead>
        <tbody>
            <?php foreach ($sales_reports as $row) { ?>
            <tr>
                <td><?php echo h($row["report_date"]); ?></td>
                <td><?php echo number_format((float) $row["total_sales_amount"], 2); ?></td>
                <td><?php echo number_format((float) $row["total_purchase_cost"], 2); ?></td>
                <td><?php echo number_format((float) $row["profit_loss"], 2); ?></td>
            </tr>
            <?php } ?>
            <?php if (!$sales_reports) { ?><tr><td colspan="4">No sales yet.</td></tr><?php } ?>
        </tbody>
    </table>
</div>

<div class="card">
    <h2>Purchase report (<?php echo h($report_type); ?>)</h2>
    <table>
        <thead>
            <tr><th>Date</th><th>Total purchases</th></tr>
        </thead>
        <tbody>
            <?php foreach ($purchase_reports as $row) { ?>
            <tr>
                <td><?php echo h($row["report_date"]); ?></td>
                <td><?php echo number_format((float) $row["total_purchase_amount"], 2); ?></td>
            </tr>
            <?php } ?>
            <?php if (!$purchase_reports) { ?><tr><td colspan="2">No purchases yet.</td></tr><?php } ?>
        </tbody>
    </table>
</div>

<?php require_once "includes/footer.php"; ?>
