<?php
require_once "includes/db.php";
require_once "includes/auth.php";

require_login();
require_role("Admin", "Pharmacist");

$page_title = "Suppliers";
$error = "";
$msg = ["saved" => "Saved.", "deleted" => "Deleted."][$_GET["msg"] ?? ""] ?? "";
$edit_supplier = null;
$is_ajax = !empty($_POST["ajax"]);

function supplier_json_response($data) {
    header("Content-Type: application/json");
    echo json_encode($data);
    exit;
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $action = $_POST["action"] ?? "";

    if ($action === "delete") {
        $stmt = $conn->prepare("DELETE FROM suppliers WHERE supplier_id = ?");
        $stmt->bind_param("i", $_POST["id"]);
        $stmt->execute();
        $stmt->close();
        header("Location: suppliers.php?msg=deleted");
        exit;
    }

    if ($action === "add" || $action === "edit") {
        $name = trim($_POST["supplier_name"] ?? "");
        $company = trim($_POST["company_name"] ?? "");
        $contact = trim($_POST["contact_number"] ?? "");
        $id = (int) ($_POST["id"] ?? 0);

        if ($name === "" || $contact === "" || $company === "") {
            $error = "All fields are required.";
            if ($is_ajax) supplier_json_response(["ok" => false, "error" => $error]);
        } elseif ($action === "add") {
            $stmt = $conn->prepare("INSERT INTO suppliers (supplier_name, contact_number, company_name) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $name, $contact, $company);
            if (!$stmt->execute()) {
                $stmt->close();
                if ($is_ajax) supplier_json_response(["ok" => false, "error" => "Could not save supplier."]);
                $error = "Could not save supplier.";
            } else {
                $new_id = (int) $stmt->insert_id;
                $stmt->close();
                if ($is_ajax) supplier_json_response(["ok" => true, "supplier_id" => $new_id, "supplier_name" => $name]);
                header("Location: suppliers.php?msg=saved");
                exit;
            }
        } else {
            $stmt = $conn->prepare("UPDATE suppliers SET supplier_name = ?, contact_number = ?, company_name = ? WHERE supplier_id = ?");
            $stmt->bind_param("sssi", $name, $contact, $company, $id);
            $stmt->execute();
            $stmt->close();
            header("Location: suppliers.php?msg=saved");
            exit;
        }
    }
}

if (isset($_GET["edit"])) {
    $stmt = $conn->prepare("SELECT * FROM suppliers WHERE supplier_id = ?");
    $stmt->bind_param("i", $_GET["edit"]);
    $stmt->execute();
    $edit_supplier = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}

$suppliers = $conn->query("SELECT * FROM suppliers ORDER BY supplier_id")->fetch_all(MYSQLI_ASSOC);

require_once "includes/header.php";
?>

<?php if ($msg) { ?><div class="msg-ok"><?php echo h($msg); ?></div><?php } ?>
<?php if ($error) { ?><div class="msg-err"><?php echo h($error); ?></div><?php } ?>

<div class="card">
    <h2><?php echo $edit_supplier ? "Edit supplier" : "Add supplier"; ?></h2>
    <form method="post">
        <input type="hidden" name="action" value="<?php echo $edit_supplier ? "edit" : "add"; ?>">
        <input type="hidden" name="id" value="<?php echo $edit_supplier ? (int) $edit_supplier["supplier_id"] : 0; ?>">
        <div class="form-row">
            <div class="form-group">
                <label>Supplier name</label>
                <input type="text" name="supplier_name" required value="<?php echo h($edit_supplier["supplier_name"] ?? ""); ?>">
            </div>
            <div class="form-group">
                <label>Company</label>
                <input type="text" name="company_name" required value="<?php echo h($edit_supplier["company_name"] ?? ""); ?>">
            </div>
            <div class="form-group">
                <label>Contact number</label>
                <input type="text" name="contact_number" required value="<?php echo h($edit_supplier["contact_number"] ?? ""); ?>">
            </div>
        </div>
        <div class="form-actions">
            <button type="submit" class="save-btn">Save</button>
            <?php if ($edit_supplier) { ?><a class="cancel-btn" href="suppliers.php">Cancel</a><?php } ?>
        </div>
    </form>
</div>

<input type="text" class="search-box" data-table="data-table" placeholder="Search suppliers...">
<table id="data-table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Supplier</th>
            <th>Company</th>
            <th>Contact</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($suppliers as $row) { ?>
        <tr>
            <td><?php echo (int) $row["supplier_id"]; ?></td>
            <td><?php echo h($row["supplier_name"]); ?></td>
            <td><?php echo h($row["company_name"]); ?></td>
            <td><?php echo h($row["contact_number"]); ?></td>
            <td>
                <a class="edit" href="suppliers.php?edit=<?php echo (int) $row["supplier_id"]; ?>">Edit</a>
                <form method="post" class="delete-form" style="display:inline">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" value="<?php echo (int) $row["supplier_id"]; ?>">
                    <button type="submit" class="delete">Delete</button>
                </form>
            </td>
        </tr>
        <?php } ?>
    </tbody>
</table>

<?php require_once "includes/footer.php"; ?>
