<?php
// Connect to MySQL database
$conn = new mysqli("localhost", "root", "", "pharmacy_db");
if ($conn->connect_error) {
    die("Database connection failed.");
}
$conn->set_charset("utf8mb4");
