<?php
if (session_status() === PHP_SESSION_NONE) session_start();

define("LOW_STOCK", 20);
define("EXPIRY_DAYS", 30);

// Sanitize HTML output
function h($text) {
    return htmlspecialchars((string) $text, ENT_QUOTES, "UTF-8");
}

// Redirect to login if user session is empty
function require_login() {
    if (empty($_SESSION["user_id"])) {
        header("Location: login.php");
        exit;
    }
}

// Check if logged-in user matches any allowed role
function role_is(...$roles) {
    $user_role = trim((string) ($_SESSION["role"] ?? ""));
    foreach ($roles as $role) {
        if (strcasecmp($user_role, trim((string) $role)) === 0) return true;
    }
    return false;
}

// Restrict access to authorized roles
function require_role(...$roles) {
    if (!role_is(...$roles)) {
        header("Location: dashboard.php");
        exit;
    }
}

// Determine stock alert status level
function alert_status_for_stock($quantity) {
    $qty = (int) $quantity;
    if ($qty <= 10) return "Critical";
    if ($qty < LOW_STOCK) return "Warning";
    return "Normal";
}

// Format medicine category label
function medicine_category_label($category) {
    if ($category === "General") return "Medicine";
    if ($category === "Antibiotic") return "Antibiotics";
    return $category;
}

// Get badge CSS class for category
function medicine_badge_class($category) {
    return strtolower(medicine_category_label($category));
}
