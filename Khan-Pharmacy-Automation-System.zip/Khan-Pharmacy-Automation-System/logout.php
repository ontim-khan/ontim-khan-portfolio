<?php
require_once "includes/auth.php";
$_SESSION = [];
if (session_id() !== "") session_destroy();
header("Location: login.php");
exit;
