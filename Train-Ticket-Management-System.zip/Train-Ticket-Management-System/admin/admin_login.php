<?php
include '../db.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user = $conn->real_escape_string($_POST['username']);
    $pass = $_POST['password'];

    $res = $conn->query("SELECT * FROM admin WHERE username='$user'");
    if ($res->num_rows == 1) {
        $a = $res->fetch_assoc();
        if ($pass === $a['password']) {  // Plain text password comparison
            $_SESSION['admin_id'] = $a['admin_id'];
            header('Location: dashboard.php');
            exit;
        } else {
            $error = 'Invalid admin credentials.';
        }
    } else {
        $error = 'Invalid admin credentials.';
    }
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Admin Login</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<div class="card">
  <h2>Admin Login</h2>
  <?php if(isset($error)) echo '<p class="error">'.htmlspecialchars($error).'</p>'; ?>
  <form method="POST">
    <label>Username</label>
    <input name="username" required>
    <label>Password</label>
    <input name="password" type="password" required>
    <button class="btn">Login</button>
  </form>
</div>
</body>
</html>

