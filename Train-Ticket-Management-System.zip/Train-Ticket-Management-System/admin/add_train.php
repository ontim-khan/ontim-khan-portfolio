<?php include '../db.php'; session_start();
if (!isset($_SESSION['admin_id'])) { header('Location: admin_login.php'); exit; }
if ($_SERVER['REQUEST_METHOD']=='POST') {
    $train_name = $conn->real_escape_string($_POST['train_name']);
    $train_number = $conn->real_escape_string($_POST['train_number']);
    $source = $conn->real_escape_string($_POST['source']);
    $destination = $conn->real_escape_string($_POST['destination']);
    $dep = $conn->real_escape_string($_POST['departure_time']);
    $arr = $conn->real_escape_string($_POST['arrival_time']);

    $conn->query("INSERT INTO trains (train_name, train_number) VALUES ('$train_name', '$train_number')");
    $train_id = $conn->insert_id;
    $conn->query("INSERT INTO routes (train_id, source, destination, departure_time, arrival_time) VALUES ($train_id, '$source', '$destination', '$dep', '$arr')");
    $msg = 'Train & route added.';
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Add Train</title><link rel="stylesheet" href="../css/style.css"></head><body>
<div class="card">
  <h2>Add Train & Route</h2>
  <?php if(isset($msg)) echo '<p class="success">'.htmlspecialchars($msg).'</p>'; ?>
  <form method="POST">
    <label>Train Name</label><input name="train_name" required>
    <label>Train Number</label><input name="train_number" required>
    <label>Source</label><input name="source" required>
    <label>Destination</label><input name="destination" required>
    <label>Departure Time</label><input name="departure_time" type="time" required>
    <label>Arrival Time</label><input name="arrival_time" type="time" required>
    <button class="btn">Add</button>
  </form>
  <p><a href="dashboard.php">Back</a></p>
</div>
</body></html>
