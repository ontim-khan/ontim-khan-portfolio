<?php
include '../db.php';
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php');
    exit;
}

// Handle cancel request
if (isset($_GET['cancel_ticket'])) {
    $cancel_id = intval($_GET['cancel_ticket']);
    $conn->query("UPDATE tickets SET status='Cancelled' WHERE ticket_id=$cancel_id");
    $msg = "Ticket #$cancel_id has been cancelled.";
}

// Fetch booked tickets
$tickets = $conn->query("
    SELECT tk.ticket_id, u.name AS user_name, u.email,
           t.train_name, r.source, r.destination,
           tk.seat_class, tk.booking_date, tk.status
    FROM tickets tk
    JOIN users u ON tk.user_id = u.user_id
    JOIN routes r ON tk.route_id = r.route_id
    JOIN trains t ON r.train_id = t.train_id
    ORDER BY tk.booking_date DESC
");
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Admin Dashboard</title>
<link rel="stylesheet" href="../css/style.css">
<style>
.table { width:100%; border-collapse: collapse; margin-top:20px; }
.table th, .table td { border:1px solid #ddd; padding:8px; text-align:center; }
.table th { background:#f4f4f4; }
.msg { background:#dff0d8; padding:10px; margin:10px 0; border:1px solid #b2dba1; }
</style>
</head>
<body>
<div class="container">
  <h2>Admin Dashboard</h2>
  
  <p>
    <a href="add_train.php" class="btn">Add Train / Route</a>
    <a href="manage_trains.php" class="btn">Manage Trains</a>
    <a href="../index.php" class="btn">View Site</a>
    <a href="logout.php" class="btn">Logout</a>
  </p>

  <?php if(isset($msg)) echo '<p class="msg">'.htmlspecialchars($msg).'</p>'; ?>

  <h3>Booked Tickets</h3>
  <table class="table">
    <thead>
      <tr>
        <th>Ticket ID</th>
        <th>User</th>
        <th>Email</th>
        <th>Train</th>
        <th>From</th>
        <th>To</th>
        <th>Seat Class</th>
        <th>Booking Date</th>
        <th>Status</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php if ($tickets->num_rows > 0): ?>
        <?php while($tk = $tickets->fetch_assoc()): ?>
          <tr>
            <td><?= htmlspecialchars($tk['ticket_id']) ?></td>
            <td><?= htmlspecialchars($tk['user_name']) ?></td>
            <td><?= htmlspecialchars($tk['email']) ?></td>
            <td><?= htmlspecialchars($tk['train_name']) ?></td>
            <td><?= htmlspecialchars($tk['source']) ?></td>
            <td><?= htmlspecialchars($tk['destination']) ?></td>
            <td><?= htmlspecialchars($tk['seat_class']) ?></td>
            <td><?= htmlspecialchars($tk['booking_date']) ?></td>
            <td><?= htmlspecialchars($tk['status']) ?></td>
            <td>
              <?php if ($tk['status'] !== 'Cancelled'): ?>
                <a href="?cancel_ticket=<?= $tk['ticket_id'] ?>" 
                   onclick="return confirm('Cancel this ticket?')">Cancel</a>
              <?php else: ?>
                <span style="color:gray;">Cancelled</span>
              <?php endif; ?>
            </td>
          </tr>
        <?php endwhile; ?>
      <?php else: ?>
        <tr><td colspan="10">No tickets booked yet.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>
</body>
</html>
