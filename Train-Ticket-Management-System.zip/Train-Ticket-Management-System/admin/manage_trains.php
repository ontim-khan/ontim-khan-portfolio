<?php
include '../db.php';
session_start();

// Check admin session
if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php');
    exit;
}

// Handle cancel request
if (isset($_GET['cancel_id'])) {
    $cancel_id = intval($_GET['cancel_id']);
    $conn->query("UPDATE routes SET status='Cancelled' WHERE route_id=$cancel_id");
    $msg = "Train route #$cancel_id has been cancelled.";
}

// Fetch all train routes
$res = $conn->query("
    SELECT r.route_id, t.train_name, r.source, r.destination, 
           r.departure_time, r.arrival_time, r.status
    FROM routes r
    JOIN trains t ON r.train_id=t.train_id
");
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Manage Trains</title>
<link rel="stylesheet" href="../css/style.css">
<style>
.table { width:100%; border-collapse: collapse; margin-top:20px; }
.table th, .table td { border:1px solid #ddd; padding:8px; text-align:center; }
.table th { background:#f4f4f4; }
.msg { background:#dff0d8; padding:10px; margin:10px 0; border:1px solid #b2dba1; }
</style>
</head>
<body>
<div class="container">
  <h2>Manage Trains</h2>

  <?php if(isset($msg)) echo '<p class="msg">'.htmlspecialchars($msg).'</p>'; ?>

  <table class="table">
    <thead>
      <tr>
        <th>Train</th>
        <th>From</th>
        <th>To</th>
        <th>Dep</th>
        <th>Arr</th>
        <th>Status</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
    <?php while($r = $res->fetch_assoc()): ?>
      <tr>
        <td><?=htmlspecialchars($r['train_name'])?></td>
        <td><?=htmlspecialchars($r['source'])?></td>
        <td><?=htmlspecialchars($r['destination'])?></td>
        <td><?=htmlspecialchars($r['departure_time'])?></td>
        <td><?=htmlspecialchars($r['arrival_time'])?></td>
        <td><?=htmlspecialchars($r['status'])?></td>
        <td>
          <?php if($r['status'] !== 'Cancelled'): ?>
            <a href="?cancel_id=<?= $r['route_id'] ?>" 
               onclick="return confirm('Cancel this train route?')">Cancel</a>
          <?php else: ?>
            <span style="color:gray;">Cancelled</span>
          <?php endif; ?>
        </td>
      </tr>
    <?php endwhile; ?>
    </tbody>
  </table>

  <p><a href="dashboard.php">⬅ Back to Dashboard</a></p>
</div>
</body>
</html>
