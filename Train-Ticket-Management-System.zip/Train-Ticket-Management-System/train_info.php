
<?php 
include 'db.php'; 
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] != 'POST') { 
    header('Location: index.php'); 
    exit; 
}

$from = $_POST['from_station'];
$to = $_POST['to_station'];
$date = $_POST['journey_date'];
$class = $_POST['seat_class'];

// Use prepared statements for security
$sql = "SELECT r.route_id, t.train_name, r.source, r.destination, r.departure_time, r.arrival_time
        FROM routes r 
        JOIN trains t ON r.train_id = t.train_id
        WHERE LOWER(r.source) LIKE ? 
          AND LOWER(r.destination) LIKE ?";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    echo "SQL Error: " . $conn->error;
    exit;
}
$from_param = '%' . strtolower($from) . '%';
$to_param = '%' . strtolower($to) . '%';
$stmt->bind_param('ss', $from_param, $to_param);
$stmt->execute();
$result = $stmt->get_result();

if (!$result) {
    echo "SQL Error: " . $conn->error;
    exit;
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Available Trains</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="container">
  <h2>Available Trains for <?= htmlspecialchars($from) ?> → <?= htmlspecialchars($to) ?> on <?= htmlspecialchars($date) ?></h2>
  <?php if ($result && $result->num_rows > 0): ?>
    <table class="table">
      <thead>
        <tr>
          <th>Train</th>
          <th>From</th>
          <th>To</th>
          <th>Dep</th>
          <th>Arr</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
      <?php while($r = $result->fetch_assoc()): ?>
        <tr>
          <td><?= htmlspecialchars($r['train_name']) ?></td>
          <td><?= htmlspecialchars($r['source']) ?></td>
          <td><?= htmlspecialchars($r['destination']) ?></td>
          <td><?= htmlspecialchars($r['departure_time']) ?></td>
          <td><?= htmlspecialchars($r['arrival_time']) ?></td>
          <td>
            <?php if(isset($_SESSION['user_id'])): ?>
              <a class="btn" href="book.php?route_id=<?= $r['route_id'] ?>&date=<?= urlencode($date) ?>&class=<?= urlencode($class) ?>">Book</a>
            <?php else: ?>
              <a class="btn" href="login.php">Login to Book</a>
            <?php endif; ?>
          </td>
        </tr>
      <?php endwhile; ?>
      </tbody>
    </table>
  <?php else: ?>
    <p class="error">No trains found.</p>
  <?php endif; ?>
  <p><a href="index.php">Search again</a></p>
</div>
</body>
</html>
