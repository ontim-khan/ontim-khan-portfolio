<?php
include 'db.php';
session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $check = $conn->query("SELECT * FROM users WHERE email = '$email'");

    if ($check && $check->num_rows > 0) {
        $error = "Email already registered.";
    } else {
        $insert = $conn->query("INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$password')");
        if ($insert) {
            header("Location: login.php?registered=1");
            exit;
        } else {
            $error = "Registration failed: " . $conn->error;
        }
    }
}
?>

<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Register</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="card">
    <h2>Register</h2>
    <?php if (isset($error)) echo '<p class="error">' . htmlspecialchars($error) . '</p>'; ?>

    <form method="POST">
        <label>Name</label>
        <input name="name" required>

        <label>Email</label>
        <input name="email" type="email" required>

        <label>Password</label>
        <input name="password" type="password" required>

        <button class="btn">Signup</button>
    </form>

    <p>Already registered? <a href="login.php">Login</a></p>
</div>
</body>
</html>
