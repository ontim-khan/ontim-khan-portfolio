<?php
include 'db.php';
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit; }
if (!isset($_GET['route_id'])) { header('Location: index.php'); exit; }

$route_id = (int)$_GET['route_id'];
$date = $conn->real_escape_string($_GET['date']);
$seat_class = $conn->real_escape_string($_GET['class']);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user = $_SESSION['user_id'];
    $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1;
    $ticket_ids = [];

    for ($i = 0; $i < $quantity; $i++) {
        $conn->query("INSERT INTO tickets (user_id, route_id, seat_class, booking_date, status) VALUES ($user, $route_id, '$seat_class', '$date', 'Booked')");
        $ticket_ids[] = $conn->insert_id;
    }

   
    header('Location: ticket_view.php');
    exit;
}

$res = $conn->query("SELECT t.train_name, r.* FROM routes r JOIN trains t ON r.train_id=t.train_id WHERE r.route_id=$route_id");
$row = $res->fetch_assoc();
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Book Ticket</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="card">
  <h2>Confirm Booking</h2>
  <p><strong>Train:</strong> <?= htmlspecialchars($row['train_name']) ?></p>
  <p><strong>Route:</strong> <?= htmlspecialchars($row['source']) ?> → <?= htmlspecialchars($row['destination']) ?></p>
  <p><strong>Date:</strong> <?= htmlspecialchars($date) ?></p>
  <p><strong>Class:</strong> <?= htmlspecialchars($seat_class) ?></p>
  <form method="POST">
    <label for="quantity"><strong>Number of Tickets:</strong></label>
    <input type="number" name="quantity" id="quantity" value="1" min="1" max="3" required>
    <br><br>
    <button class="btn">Confirm and Pay (simulate)</button>
  </form>
  <p><a href="train_info.php">Back</a></p>
</div>
</body>
</html>