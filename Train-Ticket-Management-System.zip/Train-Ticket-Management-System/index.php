<?php include 'db.php'; session_start(); ?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Bangladesh Railway - Search Trains</title>
  <link rel="stylesheet" href="css/style.css">

  <style>
    /* Reset */
    * {
      box-sizing: border-box;
    }

    body, html {
      height: 100%;
      margin: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      color: #333;
      background: url('images/bd_train_bg.jpg') no-repeat center center fixed;
      background-size: cover;
      position: relative;
      min-height: 100vh;
    }

    /* Overlay to darken background for readability */
    body::before {
      content: "";
      position: fixed;
      top: 0; left: 0; right: 0; bottom: 0;
      background-color: rgba(0, 0, 0, 0.4);
      z-index: 0;
    }

    /* Content sits above overlay */
    body > * {
      position: relative;
      z-index: 1;
    }

    /* Top bar */
    header.topbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background-color: rgba(46, 139, 87, 0.85); /* semi-transparent */
      color: white;
      padding: 15px 30px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.4);
      position: sticky;
      top: 0;
      z-index: 10;
    }

    .brand {
      display: flex;
      align-items: center;
      gap: 12px;
      font-weight: bold;
      font-size: 1.2rem;
    }

    .brand .logo {
      font-size: 2rem;
    }

    .brand .title {
      line-height: 1.1;
    }

    nav.menu a {
      color: white;
      margin-left: 25px;
      font-weight: 600;
      text-decoration: none;
      transition: color 0.3s ease;
      font-size: 1rem;
    }

    nav.menu a:hover {
      color: #b2d8b2;
    }

    /* Welcome message */
    .welcome-message {
      text-align: center;
      font-size: 28px;
      font-weight: 700;
      color: #c8f0c8;
      margin: 40px 20px 30px;
      font-family: 'Georgia', serif;
      text-shadow: 1.5px 1.5px 5px rgba(0, 0, 0, 0.75);
    }

    /* Container */
    main.container {
      max-width: 600px;
      background: rgba(255, 255, 255, 0.95);
      margin: 0 auto 60px;
      padding: 30px 40px;
      border-radius: 10px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.1);
      border: 1px solid #d7d7d7;
    }

    h2 {
      text-align: center;
      color: #2E8B57;
      margin-bottom: 30px;
      font-weight: 700;
    }

    /* Search form styles */
    form.search-form label {
      display: block;
      margin-bottom: 8px;
      font-weight: 600;
      color: #555;
      margin-top: 20px;
    }

    form.search-form input[type="text"],
    form.search-form input[type="date"],
    form.search-form select {
      width: 100%;
      padding: 10px 12px;
      font-size: 1rem;
      border: 1.8px solid #c1c1c1;
      border-radius: 6px;
      transition: border-color 0.3s ease;
    }

    form.search-form input[type="text"]:focus,
    form.search-form input[type="date"]:focus,
    form.search-form select:focus {
      outline: none;
      border-color: #2E8B57;
      box-shadow: 0 0 6px #a3d0a3;
    }

    /* Submit button */
    button.btn {
      margin-top: 30px;
      width: 100%;
      padding: 12px 0;
      background-color: #2E8B57;
      border: none;
      color: white;
      font-weight: 700;
      font-size: 1.1rem;
      border-radius: 8px;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    button.btn:hover {
      background-color: #246b46;
    }

    /* Responsive */
    @media (max-width: 650px) {
      main.container {
        padding: 20px 25px;
      }

      header.topbar {
        flex-direction: column;
        align-items: flex-start;
        gap: 10px;
      }

      nav.menu a {
        margin-left: 0;
        margin-right: 15px;
      }
    }
  </style>

</head>
<body>
  <header class="topbar">
    <div class="brand">
      <div class="logo">🇧🇩</div>
      <div class="title">Bangladesh<br>Railway</div>
    </div>
    <nav class="menu">
      <?php if(isset($_SESSION['user_id'])): ?>
        <a href="logout.php">Logout</a>
      <?php else: ?>
        <a href="login.php">Login</a>
        <a href="register.php">Register</a>
      <?php endif; ?>
      <a href="contact.php">Contact</a>
      <a href="admin/admin_login.php">Admin</a>
    </nav>
  </header>  

  <div class="welcome-message">
      Welcome to Online Train Ticket Management System
  </div>

  <main class="container">
    <h2>Search Trains</h2>
    <form method="POST" action="train_info.php" class="search-form">
      <label for="from_station">From</label>
      <input type="text" id="from_station" name="from_station" placeholder="From Station" required>

      <label for="to_station">To</label>
      <input type="text" id="to_station" name="to_station" placeholder="To Station" required>

      <label for="journey_date">Date of Journey</label>
      <input type="date" id="journey_date" name="journey_date" required>

      <label for="seat_class">Choose Class</label>
      <select id="seat_class" name="seat_class" required>
        <option value="Shovon">Shovon</option>
        <option value="AC">AC</option>
        <option value="First Class">First Class</option>
      </select>

      <button type="submit" class="btn">Search Trains</button>
    </form>
  </main>
</body>
</html>
