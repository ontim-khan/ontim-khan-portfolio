Train Ticket Management System (Simple)
--------------------------------------
Place this folder inside your XAMPP/htdocs (or equivalent) and import database.sql into MySQL (phpMyAdmin).
Default DB connection in db.php uses root with no password — change as needed.

Files:
- index.php : Home/search
- register.php, login.php, logout.php : User auth
- train_info.php : Search results
- book.php, ticket_view.php : Booking flow
- contact.php : Contact page
- admin/* : Admin area (add/manage trains)
- css/style.css : Styling

Database: run database.sql to create tables and a sample admin account.
