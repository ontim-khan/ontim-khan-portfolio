<?php include 'db.php'; session_start();
if ($_SERVER['REQUEST_METHOD']=='POST') {
    $email = $conn->real_escape_string($_POST['email']);
    $password = $_POST['password'];

    $res = $conn->query("SELECT * FROM users WHERE email='$email'");
    if ($res->num_rows==1) {
        $u = $res->fetch_assoc();
        if (password_verify($password, $u['password'])) {
            $_SESSION['user_id'] = $u['user_id'];
            $_SESSION['user_name'] = $u['name'];
            header('Location: index.php');
            exit;
        } else $error = 'Invalid credentials.';
    } else $error = 'Invalid credentials.';
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Login</title><link rel="stylesheet" href="css/style.css"></head><body>
<div class="card">
  <h2>Login</h2>
  <?php if(isset($_GET['registered'])) echo '<p class="success">Registration successful. Please login.</p>'; ?>
  <?php if(isset($error)) echo '<p class="error">'.htmlspecialchars($error).'</p>'; ?>
  <form method="POST">
    <label>Email</label><input name="email" type="email" required>
    <label>Password</label><input name="password" type="password" required>
    <button class="btn">Login</button>
  </form>
  <p>No account? <a href="register.php">Register</a></p>
</div>
</body></html>
