<?php
include 'db.php';
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Handle cancellation request (optional if you want to do it on the same page via GET)
if (isset($_GET['cancel_id'])) {
    $cancel_id = (int)$_GET['cancel_id'];

    // Update ticket status to Cancelled only if belongs to this user and status is not already Cancelled
    $stmt = $conn->prepare("UPDATE tickets SET status = 'Cancelled' WHERE ticket_id = ? AND user_id = ? AND status != 'Cancelled'");
    $stmt->bind_param('ii', $cancel_id, $user_id);
    $stmt->execute();

    // Redirect to avoid resubmission
    header('Location: ticket_view.php');
    exit;
}

// Fetch booked tickets for the logged-in user
$sql = "SELECT tk.ticket_id, t.train_name, r.source, r.destination, r.departure_time, r.arrival_time, tk.booking_date, tk.seat_class, tk.status
        FROM tickets tk
        JOIN routes r ON tk.route_id = r.route_id
        JOIN trains t ON r.train_id = t.train_id
        WHERE tk.user_id = ?
        ORDER BY tk.booking_date DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>My Booked Tickets</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="container">
    <h2>My Booked Tickets</h2>

    <?php if ($result && $result->num_rows > 0): ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Train</th>
                    <th>From</th>
                    <th>To</th>
                    <th>Departure</th>
                    <th>Arrival</th>
                    <th>Booking Date</th>
                    <th>Class</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php while ($ticket = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($ticket['train_name']) ?></td>
                    <td><?= htmlspecialchars($ticket['source']) ?></td>
                    <td><?= htmlspecialchars($ticket['destination']) ?></td>
                    <td><?= htmlspecialchars($ticket['departure_time']) ?></td>
                    <td><?= htmlspecialchars($ticket['arrival_time']) ?></td>
                    <td><?= htmlspecialchars($ticket['booking_date']) ?></td>
                    <td><?= htmlspecialchars($ticket['seat_class']) ?></td>
                    <td><?= htmlspecialchars($ticket['status']) ?></td>
                    <td>
                        <a href="ticket_view.php?id=<?= $ticket['ticket_id'] ?>">View</a>
                        <?php if ($ticket['status'] !== 'Cancelled'): ?>
                            | <a href="ticket_view.php?cancel_id=<?= $ticket['ticket_id'] ?>" onclick="return confirm('Are you sure you want to cancel this booking?');">Cancel</a>
                        <?php else: ?>
                            | Cancelled
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>You have no booked tickets.</p>
    <?php endif; ?>

    <p><a href="index.php">Search trains</a></p>
</div>
</body>
</html>
