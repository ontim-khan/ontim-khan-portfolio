<?php include 'db.php'; ?>
<!doctype html><html><head><meta charset="utf-8"><title>Contact</title><link rel="stylesheet" href="css/style.css"></head><body>
<div class="container">
  <h2>Contact Us</h2>
  <p>Email: as_ticket@gmail.com</p>
  <p>Phone: +8801819282827</p>
  <p><a href="index.php">Home</a></p>
</div>
</body></html>
