CREATE DATABASE IF NOT EXISTS train_system_1;
USE train_system_1;

CREATE TABLE IF NOT EXISTS users (
  user_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  email VARCHAR(100) UNIQUE,
  password VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS admin (
  admin_id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) UNIQUE,
  password VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS trains (
  train_id INT AUTO_INCREMENT PRIMARY KEY,
  train_name VARCHAR(100),
  train_number VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS routes (
  route_id INT AUTO_INCREMENT PRIMARY KEY,
  train_id INT,
  source VARCHAR(100),
  destination VARCHAR(100),
  departure_time TIME,
  arrival_time TIME,
  FOREIGN KEY (train_id) REFERENCES trains(train_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS tickets (
  ticket_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  route_id INT,
  seat_class VARCHAR(50),
  booking_date DATE,
  status VARCHAR(20) DEFAULT 'Booked',
  FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL,
  FOREIGN KEY (route_id) REFERENCES routes(route_id) ON DELETE SET NULL
);

/* Insert sample admin (username: admin, password: admin123) */
INSERT INTO admin (username, password) VALUES ('admin', '$2y$10$CwTycUXWue0Thq9StjUM0uJ8mFJQfVdHqz8F6C9yq9GZtY0q7r4e'); -- password: admin123 hashed with password_hash
